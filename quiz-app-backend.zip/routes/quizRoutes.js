const express = require("express");
const { createQuiz, getQuizzes, getQuizById } = require("../controllers/quizController"); 
const { authenticate, authorizeAdmin } = require("../middleware/authMiddleware"); // ✅ Import properly

const router = express.Router();

router.post("/quizzes", authenticate, authorizeAdmin, createQuiz); // ✅ Secure quiz creation
router.get("/quizzes", getQuizzes);
router.get("/quizzes/:id", getQuizById);

module.exports = router;
