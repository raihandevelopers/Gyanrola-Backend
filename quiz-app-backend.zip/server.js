const express = require("express");
const connectDB = require("./config/db");
const cors = require("cors");
require("dotenv").config();

connectDB();
const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/quizzes", require("./routes/quizRoutes"));
app.use("/api/players", require("./routes/playerRoutes"));

app.listen(5000, () => console.log("Server running on port 5000"));
