const Quiz = require("../models/Quiz");

exports.createQuiz = async (req, res) => {
  try {
    console.log("🚀 Received request to create quiz");
    console.log("Request body:", req.body);
    console.log("User:", req.user);

    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ error: "Access denied! Only admins can create quizzes." });
    }

    const quiz = new Quiz({ ...req.body, createdBy: req.user.id });
    await quiz.save();

    console.log("✅ Quiz created successfully:", quiz);
    res.status(201).json(quiz);
  } catch (error) {
    console.error("❌ Error creating quiz:", error);
    res.status(400).json({ error: "Failed to create quiz" });
  }
};


exports.getQuizzes = async (req, res) => {
  const quizzes = await Quiz.find().populate("createdBy", "name email");
  res.json(quizzes);
};

exports.getQuizById = async (req, res) => {
  const quiz = await Quiz.findById(req.params.id).populate("createdBy", "name");
  if (!quiz) return res.status(404).json({ error: "Quiz not found" });
  res.json(quiz);
};
